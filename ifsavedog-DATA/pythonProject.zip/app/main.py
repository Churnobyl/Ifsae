from fastapi import FastAPI
from motor.motor_asyncio import AsyncIOMotorClient
from app.api.v1.endpoints import router as api_router
from contextlib import asynccontextmanager
from app.db.mongo import connect_to_mongo, close_mongo_connection

@asynccontextmanager
async def lifespan(app: FastAPI):
    await connect_to_mongo()
    try:
        yield
    finally:
        await close_mongo_connection()

app = FastAPI(lifespan=lifespan)

app.include_router(api_router) 

from motor.motor_asyncio import AsyncIOMotorClient
from app.core.config import settings

class MongoDB:
  client = None
  db = None
  
mongo = MongoDB()
    
async def connect_to_mongo():
  mongo.client = AsyncIOMotorClient(settings.MONGO_URL)
  mongo.db = mongo.client[settings.MONGO_DBNAME]
  print("connect to mongo")
  
async def close_mongo_connection():
  mongo.client.close()
  print("close mongo connection")